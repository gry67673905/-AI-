#!/usr/bin/env node
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { createExternalMcpServer } from './index.js'

const server = createExternalMcpServer()
const transport = new StdioServerTransport()
await server.connect(transport)