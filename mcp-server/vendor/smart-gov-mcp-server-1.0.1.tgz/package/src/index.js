import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { z } from 'zod'

const textResult = (value) => ({
  content: [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }]
})

const errorResult = (error) => ({
  content: [{ type: 'text', text: `外部函数调用失败：${error instanceof Error ? error.message : '未知错误'}` }],
  isError: true
})

const shortText = (description) => z.string().trim().max(100, '关键词长度不能超过 100 个字符').optional().describe(description)

function registerExternalTool(server, tool) {
  server.registerTool(tool.name, {
    description: tool.description || `调用外部函数 ${tool.name}`,
    inputSchema: tool.inputSchema || {},
    annotations: {
      readOnlyHint: tool.readOnly ?? true,
      idempotentHint: tool.idempotent ?? true,
      openWorldHint: tool.openWorld ?? false
    }
  }, async (args) => {
    try {
      return textResult(await tool.handler(args))
    } catch (error) {
      return errorResult(error)
    }
  })
}

function registerReadOnlyTool(server, name, config, handler) {
  registerExternalTool(server, {
    name,
    ...config,
    readOnly: true,
    idempotent: true,
    openWorld: false,
    handler: async (args) => handler(args)
  })
}

export function registerExternalTools(server, tools = []) {
  for (const tool of tools) {
    if (!tool?.name || typeof tool.handler !== 'function') {
      throw new TypeError('外部工具必须提供 name 和 handler')
    }
    registerExternalTool(server, tool)
  }
  return server
}

export function createExternalMcpServer({ name = 'external-function-server', version = '1.0.0', tools = [] } = {}) {
  const server = new McpServer({ name, version })
  return registerExternalTools(server, tools)
}

const defaultProvider = {
  async listItems() { return [] },
  async getItem() { return null },
  async searchItems() { return [] },
  async answerQuestion() { return '暂无可用的政务事项数据。' },
  async getCase() { return null },
  async searchWindows() { return [] },
  async getMaterials() { return null },
  async searchKnowledge() { return [] },
  async getDepartment() { return null },
  async searchConsultations() { return [] }
}

export function createGovMcpServer(provider = defaultProvider) {
  const data = { ...defaultProvider, ...provider }
  const server = new McpServer({ name: 'smart-gov-assistant', version: '1.0.0' })

  registerReadOnlyTool(server, 'search_services', {
    description: '按关键词和分类搜索政务服务事项。',
    inputSchema: {
      keyword: shortText('事项名称、编码或办理关键词'),
      category: shortText('事项分类，例如社会保障、公安户政')
    }
  }, async ({ keyword = '', category = '' }) => textResult(await data.searchItems(keyword, category)))

  registerReadOnlyTool(server, 'get_service_details', {
    description: '获取指定政务服务事项的办理条件、材料、流程和注意事项。',
    inputSchema: { id: z.number().int().positive().describe('事项 ID') }
  }, async ({ id }) => {
    const item = await data.getItem(id)
    return item ? textResult(item) : textResult(`未找到事项 ID ${id}。`)
  })

  registerReadOnlyTool(server, 'list_service_categories', {
    description: '列出当前可用的政务服务分类。',
    inputSchema: {}
  }, async () => {
    const items = await data.listItems()
    return textResult([...new Set(items.map((item) => item.category).filter(Boolean))])
  })

  registerReadOnlyTool(server, 'answer_citizen_question', {
    description: '根据政务事项知识库回答群众咨询，并尽可能匹配具体事项。',
    inputSchema: { question: z.string().trim().min(1).max(1000).describe('群众提出的问题') }
  }, async ({ question }) => textResult(await data.answerQuestion(question)))

  registerReadOnlyTool(server, 'get_case_status', {
    description: '根据办件编号查询办件状态、提交时间和办理结果。',
    inputSchema: { caseId: z.number().int().positive().describe('办件编号') }
  }, async ({ caseId }) => {
    const item = await data.getCase(caseId)
    return item ? textResult(item) : textResult(`未找到办件编号 ${caseId}。`)
  })

  registerReadOnlyTool(server, 'search_service_windows', {
    description: '按窗口名称、服务范围或部门名称查询政务服务窗口。',
    inputSchema: { keyword: shortText('窗口、部门或服务范围关键词') }
  }, async ({ keyword = '' }) => textResult(await data.searchWindows(keyword)))

  registerReadOnlyTool(server, 'get_material_checklist', {
    description: '生成指定政务事项的材料清单，区分必需材料和可选材料。',
    inputSchema: { itemId: z.number().int().positive().describe('事项 ID') }
  }, async ({ itemId }) => {
    const result = await data.getMaterials(itemId)
    return result ? textResult(result) : textResult(`未找到事项 ID ${itemId}。`)
  })

  registerReadOnlyTool(server, 'search_knowledge', {
    description: '搜索政策文件、办事指南、材料模板和常见问题等政务知识库内容。',
    inputSchema: {
      keyword: z.string().trim().min(1).max(100, '关键词长度不能超过 100 个字符').describe('政策、事项或知识库关键词'),
      type: shortText('知识类型，例如政策文件、办事指南、常见问题')
    }
  }, async ({ keyword, type = '' }) => textResult(await data.searchKnowledge(keyword, type)))

  registerReadOnlyTool(server, 'get_department_details', {
    description: '查询政务部门信息及其负责的事项和服务窗口。',
    inputSchema: { departmentId: z.number().int().positive().describe('部门 ID') }
  }, async ({ departmentId }) => {
    const result = await data.getDepartment(departmentId)
    return result ? textResult(result) : textResult(`未找到部门 ID ${departmentId}。`)
  })

  registerReadOnlyTool(server, 'search_consultations', {
    description: '查询群众咨询记录，可按问题关键词或处理状态筛选。',
    inputSchema: {
      keyword: shortText('咨询问题关键词'),
      status: shortText('咨询状态，例如已答复、转人工')
    }
  }, async ({ keyword = '', status = '' }) => textResult(await data.searchConsultations(keyword, status)))

  return server
}

export function createMemoryProvider({ items = [], faq = [], cases = [], departments = [], windows = [], knowledgeDocs = [], consultations = [] } = {}) {
  const findItem = (id) => items.find((item) => item.id === Number(id)) || null
  const searchItems = async (keyword = '', category = '') => {
    const normalized = keyword.trim().toLowerCase()
    const categoryAliases = { 社保: '社会保障', 人社: '社会保障', 市监: '市场监管' }
    const normalizedCategory = categoryAliases[normalized] || normalized
    return items.filter((item) => {
      const relatedFaq = faq.some((entry) => entry.itemId === item.id && entry.q.toLowerCase().includes(normalized))
      const hit = !normalized || item.name.toLowerCase().includes(normalized) || item.code.toLowerCase().includes(normalized) || item.category.toLowerCase().includes(normalized) || item.category === normalizedCategory || item.serviceObject.toLowerCase().includes(normalized) || relatedFaq
      return hit && (!category || item.category === category)
    })
  }
  const answerQuestion = async (question) => {
    const match = faq.find((entry) => question.includes(entry.q) || entry.q.includes(question))
    if (match) return { answer: match.answer, item: findItem(match.itemId) }
    const item = (await searchItems(question))[0]
    return item ? { answer: `已匹配事项：${item.name}`, item } : { answer: '暂未匹配到具体事项，请提供事项名称或关键词。', item: null }
  }
  const getCase = async (id) => {
    const item = cases.find((entry) => entry.id === Number(id))
    if (!item) return null
    const { phone, idCard, ...safeItem } = item
    return safeItem
  }
  const searchWindows = async (keyword = '') => {
    const normalized = keyword.trim().toLowerCase()
    return windows.filter((window) => {
      const department = departments.find((item) => item.id === window.deptId)
      return !normalized || [window.name, window.location, window.serviceScope, department?.name].some((value) => value?.toLowerCase().includes(normalized))
    }).map((window) => ({ ...window, departmentName: departments.find((item) => item.id === window.deptId)?.name || null }))
  }
  const getMaterials = async (id) => {
    const item = findItem(id)
    if (!item) return null
    return {
      itemId: item.id,
      itemName: item.name,
      required: item.materials.filter((material) => material.required),
      optional: item.materials.filter((material) => !material.required),
      notice: item.notice
    }
  }
  const searchKnowledge = async (keyword = '', type = '') => {
    const normalized = keyword.trim().toLowerCase()
    return knowledgeDocs.filter((doc) => {
      const hit = !normalized || [doc.title, doc.content, doc.type].some((value) => value?.toLowerCase().includes(normalized))
      return hit && (!type || doc.type === type)
    })
  }
  const getDepartment = async (id) => {
    const department = departments.find((item) => item.id === Number(id))
    if (!department) return null
    const { phone, ...safeDepartment } = department
    return {
      ...safeDepartment,
      items: items.filter((item) => item.deptId === department.id).map(({ id: itemId, code, name, category }) => ({ itemId, code, name, category })),
      windows: windows.filter((window) => window.deptId === department.id).map(({ id: windowId, name, location, serviceScope, status }) => ({ windowId, name, location, serviceScope, status }))
    }
  }
  const searchConsultations = async (keyword = '', status = '') => {
    const normalized = keyword.trim().toLowerCase()
    return consultations.filter((consultation) => {
      const hit = !normalized || consultation.question.toLowerCase().includes(normalized)
      return hit && (!status || consultation.status === status)
    }).map(({ user, ...consultation }) => consultation)
  }
  return { listItems: async () => items, getItem: async (id) => findItem(id), searchItems, answerQuestion, getCase, searchWindows, getMaterials, searchKnowledge, getDepartment, searchConsultations }
}