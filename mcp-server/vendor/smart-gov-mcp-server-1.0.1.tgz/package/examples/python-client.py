"""Python MCP client example: list tools and call an external function."""

import asyncio
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    project_dir = Path(__file__).resolve().parents[1]
    server_file = project_dir / "examples" / "vscode-server.js"
    server_params = StdioServerParameters(
        command="node",
        args=[str(server_file)],
        cwd=str(project_dir),
    )

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tool_list = await session.list_tools()
            print("可用工具:")
            for tool in tool_list.tools:
                print(f"- {tool.name}: {tool.description}")

            result = await session.call_tool(
                "lookup_project_status",
                {"project": "demo"},
            )
            print("调用结果:")
            for content in result.content:
                if hasattr(content, "text"):
                    print(content.text)


if __name__ == "__main__":
    asyncio.run(main())
