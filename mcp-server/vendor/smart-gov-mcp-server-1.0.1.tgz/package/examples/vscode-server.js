import { z } from 'zod'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { createExternalMcpServer } from '../src/index.js'

const server = createExternalMcpServer({
  name: 'vscode-external-tools',
  version: '1.0.0',
  tools: [
    {
      name: 'lookup_project_status',
      description: '查询外部项目状态',
      inputSchema: {
        project: z.string().trim().min(1)
      },
      async handler({ project }) {
        return { project, status: 'running', source: 'external function' }
      }
    },
    {
      name: 'update_project_status',
      description: '更新外部项目状态',
      inputSchema: {
        project: z.string().trim().min(1),
        status: z.enum(['running', 'paused', 'done'])
      },
      readOnly: false,
      idempotent: true,
      async handler({ project, status }) {
        return { project, status, updated: true, source: 'external function' }
      }
    }
  ]
})

await server.connect(new StdioServerTransport())
