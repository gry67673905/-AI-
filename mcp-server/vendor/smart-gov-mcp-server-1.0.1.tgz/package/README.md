# Smart Government MCP Server

将智慧政务事项能力以 MCP tools（function calling）提供给 Claude Desktop、Cursor 或其他 MCP 客户端。

## 本地运行

```bash
cd mcp-server
npm install
npm start
```

服务使用 `stdio` 传输，不会向 stdout 输出日志。发布包内置的 CLI 不注册业务工具；业务项目通过库 API 传入自己的外部函数。

## MCP 客户端配置

```json
{
  "mcpServers": {
    "smart-gov": {
      "command": "node",
      "args": ["D:/path/to/project/mcp-server/src/cli.js"]
    }
  }
}
```

库本身不绑定固定业务工具。调用方传入哪些外部函数，MCP 客户端就能发现哪些工具。

VS Code 验证示例：

```bash
npm run start:example
```

示例位于 `examples/vscode-server.js`，注册了两个外部函数：`lookup_project_status` 和 `update_project_status`。其中后者显式设置 `readOnly: false`，用于验证写入型工具元数据。

## Python 调用

安装 Python MCP SDK：

```bash
python -m pip install -r requirements-python.txt
```

运行 Python 客户端：

```bash
python examples/python-client.py
```

`examples/python-client.py` 会通过 stdio 启动 `examples/vscode-server.js`，然后使用官方 Python MCP Client 完成：

1. `session.list_tools()` 获取 `tool_list`；
2. `session.call_tool()` 调用外部函数 `lookup_project_status`。

Python 客户端也可以连接其他 MCP 服务，只需修改 `StdioServerParameters` 中的 `command`、`args` 和 `cwd`。

## 打包和发布

在本目录执行：

```bash
npm install
npm run check
npm run pack:release
```

成功后会生成 `smart-gov-mcp-server-1.0.0.tgz`。把这个文件交给别人安装：

```bash
npm install ./smart-gov-mcp-server-1.0.0.tgz
```

发布到 npm registry：

```bash
npm login
npm publish
```

发布前需要把 `package.json` 的 `name` 改成 npm 上未被占用的名称，并递增 `version`。

## 外部函数模式

```js
import { z } from 'zod'
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { createExternalMcpServer } from 'smart-gov-mcp-server'

const server = createExternalMcpServer({
  name: 'my-business-tools',
  version: '1.0.0',
  tools: [
    {
      name: 'search_services',
      description: '搜索政务事项',
      inputSchema: {
        keyword: z.string().trim().min(1).max(100)
      },
      async handler({ keyword }) {
        return await externalApi.searchServices(keyword)
      }
    },
    {
      name: 'get_case_status',
      description: '查询办件状态',
      inputSchema: {
        caseId: z.number().int().positive()
      },
      async handler({ caseId }) {
        return await externalApi.getCaseStatus(caseId)
      }
    }
  ]
})

await server.connect(new StdioServerTransport())
```

`handler` 是调用方提供的外部函数，可以请求 REST API、数据库、RAG 服务或其他系统。MCP 层只负责工具注册、参数校验、函数调用和结果封装。

## 兼容政务 Provider 模式

```js
import { createGovMcpServer, createMemoryProvider } from 'smart-gov-mcp-server'

const provider = createMemoryProvider({ items, faq })
const server = createGovMcpServer(provider)
```

使用 stdio 启动注入了业务数据的服务：

```js
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js'
import { createGovMcpServer } from 'smart-gov-mcp-server'

const server = createGovMcpServer({
  async searchItems(keyword, category) { return db.searchItems(keyword, category) },
  async getItem(id) { return db.items.find((item) => item.id === id) },
  async answerQuestion(question) { return knowledgeBase.answer(question) }
})

await server.connect(new StdioServerTransport())
```

生产环境可将 provider 替换为数据库、REST API 或 RAG 服务适配器。基础实现需要 `listItems`、`getItem`、`searchItems`、`answerQuestion`；启用办件、窗口、材料、知识库、部门和咨询工具时，再实现 `getCase`、`searchWindows`、`getMaterials`、`searchKnowledge`、`getDepartment`、`searchConsultations`。